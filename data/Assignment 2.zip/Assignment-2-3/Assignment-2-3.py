from mevis import *
   
def printstr(SomeString):
	print(f"The GUI called printstr with: {SomeString}")
	
def buttonPressed():
  current_value = ctx.field("persistentToggle").value
  current_value = not current_value 
  if current_value:
    ctx.field("text").value = "On"
  else:
    ctx.field("text").value = "Off"
	
## FieldListener and Counter examples	
	
# If the Slider backing field changes, push the change to the Counter.
def updateCounter(changedField):
	ctx.field("MyCounter.currentValue").value = changedField.value

# If the Counter's value changes, push the change to the Slider.
def updateSliderField(changedField):
	ctx.field("MySliderField").value = changedField.value

# If the count changes, obtain the max-count and compute the % towards maxCount.
def updateProgressBar():
	maxCount = ctx.field("MyCounter.maxValue").value
	ctx.field("MyProgressBar").value = ctx.field("MySliderField").value / float(maxCount)
	
# To easily find the names to put into ctx.field(...)
# 	-> Open the automatic panel and right-click a field, e.g. MyCounter's currentValue field.
#		Click `Copy Name`

# Increment the counter value by first obtaining the current counter value.
# Afterwards, we increment our local variable `counter_value` by 1 and write the result back into the 
# counter module.
def increment():
	counter_value = ctx.field("MyCounter.currentValue").value
	counter_value += 1
	ctx.field("MyCounter.currentValue").value = counter_value

# The same as above but we decrement instead.
def decrement():
	counter_value = ctx.field("MyCounter.currentValue").value
	counter_value -= 1
	ctx.field("MyCounter.currentValue").value = counter_value

# We start the counting by setting autoStep to True.
def startCount():
	ctx.field("MyCounter.autoStep").value = True

# And stop it by setting it to False
def stopCount():
	ctx.field("MyCounter.autoStep").value = False